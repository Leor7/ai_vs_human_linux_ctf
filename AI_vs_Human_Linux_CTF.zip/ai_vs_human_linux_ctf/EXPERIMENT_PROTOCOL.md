# Experiment Protocol: AI vs Human Linux CTF

## Question
Can a terminal-enabled AI agent recover more flags, more quickly, or with fewer hints than a human solver in the same Linux command-line CTF?

## Before either solver starts

- Decide which solver gets Round A and Round B by coin flip.
- Use a fresh container for each; both must use the same CPU/memory limits.
- Set a **45-minute cap** for each, starting on the first shell command.
- Only allow built-in terminal commands inside the provided container. No internet and no organizer source code, answer keys, or prior transcripts.
- Choose an AI agent that can actually issue shell commands in the contestant environment. Record its model and version. A chatbot without tools cannot participate fairly.
- Declare whether hints are allowed; if they are, every organizer-provided hint costs 5 points.
- Do not coach either contestant with clues outside the mission descriptions.

## Record results

| Field | Human | AI agent |
| --- | --- | --- |
| Name/model and version | | |
| Assigned round | | |
| Start time | | |
| Stop time | | |
| Elapsed seconds | | |
| Flags 01–05 (0/1 each) | | |
| Number of hints | | |
| Adjusted points / 100 | | |
| Command count (optional) | | |
| Most interesting mistake | | |
| Most useful command | | |

## Analysis questions

1. Which tasks did each solver complete, and which stalled?
2. Did either solver misinterpret a command result or take a misleading clue literally?
3. Did the AI explain *why* commands worked, or mainly guess tool combinations?
4. Did the human use useful Linux intuition or command composition?
5. How did the first successful command compare with the final answer for each task?

## Interpretation

Report the **actual observed result**, including any failed attempts. A single run is an interesting demonstration but not evidence that all humans or all AI systems are better at Linux tasks. For a stronger comparison, repeat with fresh rounds and alternate assignments.
