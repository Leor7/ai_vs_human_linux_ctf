#!/usr/bin/env bash
set -euo pipefail
round="${1:-A}"
if [[ "$round" != 'A' && "$round" != 'B' ]]; then
  echo 'Usage: scripts/run.sh A|B' >&2; exit 2
fi
docker run --rm -it --network none --cap-drop ALL \
  --security-opt no-new-privileges --pids-limit 128 \
  --memory 512m --cpus 1 "linux-ctf:${round,,}"
