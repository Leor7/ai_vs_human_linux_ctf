#!/usr/bin/env python3
"""Generate a local, safe Linux CTF. Keep generated/ private."""
from __future__ import annotations
import argparse
import base64
import io
import json
import random
import secrets
import shutil
import tarfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHALLENGES = {
    '01': 'Hidden Handoff',
    '02': 'Night Shift Logs',
    '03': 'Broken Transmission',
    '04': 'Cold Storage',
    '05': 'Command Shadow',
}

def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')

def generate(round_name: str, force: bool = False) -> Path:
    dst = ROOT / 'generated' / f'round_{round_name}'
    if dst.exists():
        if not force:
            raise SystemExit(f'{dst} already exists. Pass --force to replace its flags and files.')
        shutil.rmtree(dst)
    player = dst / 'player'
    arena = player / 'arena'
    arena.mkdir(parents=True)
    flags = {k: f'CTF{{{name}_{secrets.token_hex(5)}}}' for k, name in [
        ('01', 'dotfile'), ('02', 'logtrail'), ('03', 'signal'),
        ('04', 'archive'), ('05', 'shell')
    ]}
    write(arena / 'README_FIRST.txt', '''AI vs Human: Linux Command-Line CTF
====================================

Mission: recover 5 unique CTF{...} flags using only the terminal.
Start in ~/arena. There is ONE flag per numbered mission folder.
Read each MISSION.txt file for the objective. You have 45 minutes.

Rules:
- Work as ctfplayer. Do not use sudo, install packages, or escape the container.
- You may use built-in Linux commands, read files, and create temporary files.
- No internet, no hints unless the organizer logs a hint.
- Do not read organizer files, Docker build context, or answer keys.
- Submit flags as 01: CTF{...}, 02: CTF{...}, etc.

Suggested start: pwd && ls -la && find . -name MISSION.txt
''')

    # 01 - dotfile discovery
    p = arena / '01-hidden-handoff'
    write(p / 'MISSION.txt', '''01 / HIDDEN HANDOFF
A departing operator hid the handoff code in this directory.
The normal directory listing does not tell the whole story.
Find the CTF flag. Skill: viewing hidden entries and reading files.
''')
    write(p / 'shift-summary.txt', 'No incident was reported on this shift.\n')
    write(p / '.handoff-note', f'Night shift handoff code: {flags["01"]}\n')

    # 02 - incident log investigation
    p = arena / '02-night-shift-logs'
    write(p / 'MISSION.txt', '''02 / NIGHT SHIFT LOGS
A service audit is buried among noisy application records.
Find the ONLY event with actor=auditor and verdict=approved.
The flag is in that exact record. Skill: grep, awk, filtering logs.
''')
    start = datetime(2026, 11, 7, 1, 0, tzinfo=timezone.utc)
    rng = random.Random(20261107)
    rows = []
    for i in range(240):
        stamp = (start + timedelta(seconds=i * 13)).isoformat().replace('+00:00','Z')
        actor = rng.choice(['buildbot', 'scanner', 'auditor', 'operator'])
        verdict = rng.choice(['denied', 'pending', 'review'])
        rows.append(f'{stamp} service=iam actor={actor} verdict={verdict} request=req-{1000+i} trace=none')
    rows.insert(173, f'2026-11-07T01:37:21Z service=iam actor=auditor verdict=approved request=req-7777 trace={flags["02"]}')
    write(p / 'access.log', '\n'.join(rows) + '\n')

    # 03 - out-of-order base64 fragments
    p = arena / '03-broken-transmission'
    write(p / 'MISSION.txt', '''03 / BROKEN TRANSMISSION
A base64-encoded flag was transmitted in numbered fragments.
Lines use the syntax sequence|fragment but arrived OUT OF ORDER.
Sort the sequence numerically, concatenate fragments with no newline,
and base64-decode the result. Skill: sort, cut, tr, base64.
''')
    encoded = base64.b64encode(flags['03'].encode()).decode()
    parts = [encoded[i:i+8] for i in range(0, len(encoded), 8)]
    chunks = [(i + 1, chunk) for i, chunk in enumerate(parts)]
    rng.shuffle(chunks)
    write(p / 'transmission.txt', '\n'.join(f'{num}|{chunk}' for num, chunk in chunks) + '\n')

    # 04 - tar archive and ordered fragment reconstruction
    p = arena / '04-cold-storage'
    p.mkdir(parents=True)
    write(p / 'MISSION.txt', '''04 / COLD STORAGE
The archival crew stored one flag in backup.tar.gz, split into shards.
The archive includes a CSV manifest. The manifest's ORDER column
specifies how to join shard contents to recover the flag.
Skill: tar, CSV inspection, sorting and shell loops.
''')
    pieces = [flags['04'][i:i+6] for i in range(0, len(flags['04']), 6)]
    names = [f'frag-{chr(97+i)}.txt' for i in range(len(pieces))]
    rng.shuffle(names)
    manifest = 'order,filename\n' + ''.join(f'{i+1},{n}\n' for i,n in enumerate(names))
    contents = {f'shards/{n}': pieces[i].encode() for i,n in enumerate(names)}
    contents['manifest.csv'] = manifest.encode()
    contents['NOTICE.txt'] = b'Use the manifest order; alphabetical file order is a trap.\n'
    with tarfile.open(p / 'backup.tar.gz', 'w:gz') as tf:
        for name, data in contents.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            tf.addfile(info, io.BytesIO(data))

    # 05 - shell function shadows a real executable
    p = arena / '05-command-shadow'
    write(p / 'MISSION.txt', '''05 / COMMAND SHADOW
The healthcheck command always prints a reassuring message, but the
REAL executable in your PATH contains the final flag.
Investigate how Bash resolves that name, then invoke the executable
instead of the shell function. Skills: type -a, command, PATH.
''')
    binary = player / 'bin' / 'healthcheck'
    write(binary, f'#!/bin/sh\nprintf \'%s\\n\' \'service: ready | token: {flags["05"]}\'\n')
    binary.chmod(0o755)

    answer_key = {
        'round': round_name,
        'challenges': CHALLENGES,
        'flags': flags,
        'warning': 'ORGANIZER ONLY. Do not publish or share with contestants.',
    }
    write(dst / 'answer_key.json', json.dumps(answer_key, indent=2) + '\n')
    print(f'Generated Round {round_name}: {player}')
    print(f'Private organizer key: {dst / "answer_key.json"}')
    return dst

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round', choices=['A','B'], required=True)
    parser.add_argument('--force', action='store_true', help='Replace previous flags for this round')
    args = parser.parse_args()
    generate(args.round, args.force)
