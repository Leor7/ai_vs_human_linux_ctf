#!/usr/bin/env python3
"""Create a standalone HTML scoreboard for the write-up."""
import argparse
import html
import json
from pathlib import Path

STYLE = '''
* { box-sizing:border-box } body { font-family:system-ui,sans-serif; background:#101827; color:#e7edf8; margin:0; padding:40px 20px }
main { max-width:900px; margin:auto } h1 { font-size:clamp(1.6rem, 4vw, 2.6rem); margin:6px 0 12px }
.sub {color:#aab9d4;margin-bottom:30px}.grid { display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px }
.card { background:#1a2840;border:1px solid #354561;border-radius:16px;padding:24px } h2 {margin-top:0}
.score {font-size:48px;font-weight:750;letter-spacing:-2px}.muted{color:#aab9d4} .meter{background:#364763;border-radius:20px;height:14px;overflow:hidden;margin:12px 0 24px}
.fill{background:#67d3b6;height:100%}.pill{display:inline-block;background:#233a4d;border-radius:20px;padding:6px 10px;margin:3px 2px;font-size:14px}
footer{margin-top:28px;color:#aab9d4;font-size:14px} strong{color:#fff}
'''

def card(r):
    name = html.escape(r['solver'])
    score = max(0, min(100, int(r['adjusted_points'])))
    elapsed = int(r['elapsed_seconds'])
    level_spans = ''.join(f'<span class="pill">{html.escape(k)}: {"✓" if v else "—"}</span>'
                          for k,v in sorted(r['correct'].items()))
    return f'''<section class="card"><h2>{name} · Round {html.escape(r["round"])}</h2>
    <div class="score">{score}<span class="muted">/100</span></div>
    <div class="meter"><div class="fill" style="width:{score}%"></div></div>
    <p><strong>{r['solved']} / {r['total']} flags</strong> solved</p>
    <p>{level_spans}</p>
    <p class="muted">Time: {elapsed//60}m {elapsed%60}s · Hints: {r['hints_used']} · Raw: {r['raw_points']}/100</p>
    </section>'''

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('results', nargs='+', type=Path)
    p.add_argument('--out', type=Path, default=Path('results/scoreboard.html'))
    args = p.parse_args()
    data = [json.loads(path.read_text(encoding='utf-8')) for path in args.results]
    winner = sorted(data, key=lambda r:(r['adjusted_points'], -r['elapsed_seconds']), reverse=True)[0]
    cards = '\n'.join(card(r) for r in data)
    doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>AI vs Human · Linux CTF</title><style>{STYLE}</style></head><body><main>
    <div class="sub">LINUX · COMMAND LINE · CYBERSECURITY</div>
    <h1>Can AI Solve a Linux CTF Better Than a Human?</h1>
    <p class="sub">Five command-line challenges. Equal time limit. Independent clean containers.</p>
    <div class="grid">{cards}</div>
    <footer>Top score: {html.escape(winner['solver'])}. Tie-breaker: faster elapsed time. One trial does not prove general human or AI superiority.</footer>
    </main></body></html>'''
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(doc, encoding='utf-8')
    print(f'Wrote {args.out}')
