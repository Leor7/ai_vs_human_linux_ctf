#!/usr/bin/env python3
"""Check a solver's flags without exposing the organizer's answer key."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def check_submission(round_name: str, submission: Path, solver: str,
                     elapsed_seconds: int, hints_used: int) -> dict:
    key_path = ROOT / 'generated' / f'round_{round_name}' / 'answer_key.json'
    key = json.loads(key_path.read_text(encoding='utf-8'))
    entered = {}
    for line in submission.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        match = re.fullmatch(r'(0?[1-5])\s*[:=]\s*(CTF\{[^\s{}]+\})', line)
        if not match:
            print(f'Warning: Ignoring malformed submission line: {line[:100]}')
            continue
        entered[match.group(1).zfill(2)] = match.group(2)
    correct = {num: entered.get(num) == flag for num, flag in key['flags'].items()}
    solved = sum(correct.values())
    raw = solved * 20
    adjusted = max(0, raw - 5 * hints_used)
    result = {
        'solver': solver,
        'round': round_name,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': elapsed_seconds,
        'hints_used': hints_used,
        'correct': correct,
        'solved': solved,
        'total': len(correct),
        'raw_points': raw,
        'adjusted_points': adjusted,
    }
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round', required=True, choices=['A','B'])
    parser.add_argument('--submission', type=Path, required=True)
    parser.add_argument('--solver', required=True, help='e.g. Human or AI Agent')
    parser.add_argument('--elapsed-seconds', type=int, required=True)
    parser.add_argument('--hints', type=int, default=0)
    parser.add_argument('--out', type=Path, help='Write a JSON result (never includes flags)')
    args = parser.parse_args()
    if args.elapsed_seconds < 0 or args.hints < 0:
        parser.error('--elapsed-seconds and --hints must be nonnegative')
    result = check_submission(args.round, args.submission, args.solver,
                              args.elapsed_seconds, args.hints)
    print(f'\n{result["solver"]} / Round {result["round"]}')
    for number, good in result['correct'].items():
        print(f'  {number}: {"CORRECT" if good else "not solved"}')
    print(f'Flags: {result["solved"]}/{result["total"]} | Raw: {result["raw_points"]}/100')
    print(f'Hint penalty: {result["hints_used"] * 5} | Adjusted: {result["adjusted_points"]}/100')
    print(f'Time: {result["elapsed_seconds"] // 60}m {result["elapsed_seconds"] % 60}s')
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        print(f'Saved {args.out}')
